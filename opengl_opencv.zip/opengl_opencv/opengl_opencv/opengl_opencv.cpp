#include <opencv2/opencv.hpp>
#include <opencv2/highgui.hpp>

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
//#include <glm/gtc/type_ptr.hpp>

#include <learnopengl/camera.h>
#include <learnopengl/shader_s.h>

#include <string>
#include <thread>
#include <chrono>
#include <iostream>

// settings
const unsigned int SCR_WIDTH = 1440;
const unsigned int SCR_HEIGHT = 900;

//const unsigned int SCR_WIDTH = 800;
//const unsigned int SCR_HEIGHT = 600;

// camera
Camera camera(glm::vec3(0.0f, 0.0f, 1.0f));
float lastX = (float)SCR_WIDTH / 2.0;
float lastY = (float)SCR_HEIGHT / 2.0;
bool firstMouse = true;

// timing
float deltaTime = 0.0f;
float lastFrame = 0.0f;

//texture
bool firstLoad = true;


//url
std::string ip_l = "";
std::string port_l = "";
std::string username_l = "";
std::string  pwd_l = "";

std::string ip_r = "";
std::string port_r = "";
std::string username_r = "";
std::string pwd_r = "";

std::string url_l = "rtsp://" + username_l + ":" + pwd_l + "@" + ip_l + ":" + port_l + "/stream1";
std::string url_r = "rtsp://" + username_r + ":" + pwd_r + "@" + ip_r + ":" + port_r + "/stream1";

//-3.491f, -1.96f, -4.0f, 0.0f, 0.0f,
//-3.491f, 1.96f, -4.0f, 0.0f, 1.0f,
//3.491f, 1.96f, -4.0f, 1.0f, 1.0f,
//3.491f, 1.96f, -4.0f, 1.0f, 1.0f,
//3.491f, -1.96f, -4.0f, 1.0f, 0.0f,
//-3.491f, -1.96f, -4.0f, 0.0f, 0.0f



//class for handle video stream
class VideoSource {     // The class

private:
    cv::VideoCapture cap;
    cv::Mat frame;
    cv::Mat tmp;
    bool continueUpdate = true;
    bool doneUpdate = false;

    void update() {
        while (continueUpdate && cap.isOpened() && cap.grab()) {
            try {
                if (!cap.retrieve(tmp)) {
                    break;
                }
                cv::cvtColor(tmp, tmp, cv::COLOR_BGR2RGB);
                cv::flip(tmp, tmp, 0);
                tmp.copyTo(frame);
            }
            catch (cv::Exception e) {
                std::cout << e.what() << std::endl;
                break;
            }
            catch (std::exception e) {
                std::cout << e.what() << std::endl;
                break;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        doneUpdate = true;
    }

public:
    VideoSource(std::string url) {
        cap = cv::VideoCapture(url);
        if (cap.isOpened()) {
            std::thread t(&VideoSource::update, this);
            t.detach();
        }
    }

    VideoSource(int num) {
        cap = cv::VideoCapture(num);
        if (cap.isOpened()) {
            std::thread t(&VideoSource::update, this);
            t.detach();
        }
    }

    bool checkOpened() {
        return cap.isOpened();
    }

    cv::Mat getframe() {
        return frame;
    }

    void finish() {
        continueUpdate = false;
        while (!doneUpdate) {}
        cap.release();
    }

};



void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void processInput(GLFWwindow* window);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void processInput(GLFWwindow* window);

unsigned int loadTexture(const char* path);
unsigned int loadTexture(cv::VideoCapture cap);
unsigned int loadTexture(cv::Mat img);
void updateTexture(cv::VideoCapture cap, unsigned int textureID);
void updateTexture(cv::Mat img, unsigned int textureID);


//version2
int main(void)
{
    //init
    VideoSource vs_r(url_r);
    VideoSource vs_l(url_l);

    if (!vs_r.checkOpened() || !vs_l.checkOpened()) {
        std::cout << "Cannot open camera\n";
        return -1;
    }

    while (vs_r.getframe().empty() || vs_l.getframe().empty()) {}

    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "LearnOpenGL", NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetScrollCallback(window, scroll_callback);

    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);


    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    Shader plane("plane.vs", "projectTexture.fs");

    float planeVertices[] = {
        -1.00f,		-1.00f,		-1.0f,		0.21875f,		0.0f,
        -1.00f,		-0.5f,		-1.0f,		0.21875f,		0.25f,
        -0.5f,		-0.5f,		-1.0f,		0.359375f,		0.25f,
        -0.5f,		-0.5f,		-1.0f,		0.359375f,		0.25f,
        -0.5f,		-1.00f,		-1.0f,		0.359375f,		0.0f,
        -1.00f,		-1.00f,		-1.0f,		0.21875f,		0.0f,
        -0.50f,		-1.00f,		-1.0f,		0.359375f,		0.0f,
        -0.50f,		-0.5f,		-1.0f,		0.359375f,		0.25f,
        0.0f,		-0.5f,		-1.0f,		0.5f,		    0.25f,
        0.0f,		-0.5f,		-1.0f,		0.5f,		    0.25f,
        0.0f,		-1.00f,		-1.0f,		0.5f,		    0.0f,
        -0.50f,		-1.00f,		-1.0f,		0.359375f,		0.0f,
        0.00f,		-1.00f,		-1.0f,		0.5f,		    0.0f,
        0.00f,		-0.5f,		-1.0f,		0.5f,		    0.25f,
        0.5f,		-0.5f,		-1.0f,		0.640625f,		0.25f,
        0.5f,		-0.5f,		-1.0f,		0.640625f,		0.25f,
        0.5f,		-1.00f,		-1.0f,		0.640625f,		0.0f,
        0.00f,		-1.00f,		-1.0f,		0.5f,		    0.0f,
        0.50f,		-1.00f,		-1.0f,		0.640625f,		0.0f,
        0.50f,		-0.5f,		-1.0f,		0.640625f,		0.25f,
        1.0f,		-0.5f,		-1.0f,		0.78125f,		0.25f,
        1.0f,		-0.5f,		-1.0f,		0.78125f,		0.25f,
        1.0f,		-1.00f,		-1.0f,		0.78125f,		0.0f,
        0.50f,		-1.00f,		-1.0f,		0.640625f,		0.0f,
        -1.00f,		-0.50f,		-1.0f,		0.21875f,		0.25f,
        -1.00f,		0.0f,		-1.0f,		0.21875f,		0.5f,
        -0.5f,		0.0f,		-1.0f,		0.359375f,		0.5f,
        -0.5f,		0.0f,		-1.0f,		0.359375f,		0.5f,
        -0.5f,		-0.50f,		-1.0f,		0.359375f,		0.25f,
        -1.00f,		-0.50f,		-1.0f,		0.21875f,		0.25f,
        -0.50f,		-0.50f,		-1.0f,		0.359375f,		0.25f,
        -0.50f,		0.0f,		-1.0f,		0.359375f,		0.5f,
        0.0f,		0.0f,		-1.0f,		0.5f,		    0.5f,
        0.0f,		0.0f,		-1.0f,		0.5f,		    0.5f,
        0.0f,		-0.50f,		-1.0f,		0.5f,		    0.25f,
        -0.50f,		-0.50f,		-1.0f,		0.359375f,		0.25f,
        0.00f,		-0.50f,		-1.0f,		0.5f,		    0.25f,
        0.00f,		0.0f,		-1.0f,		0.5f,		    0.5f,
        0.5f,		0.0f,		-1.0f,		0.640625f,		0.5f,
        0.5f,		0.0f,		-1.0f,		0.640625f,		0.5f,
        0.5f,		-0.50f,		-1.0f,		0.640625f,		0.25f,
        0.00f,		-0.50f,		-1.0f,		0.5f,		    0.25f,
        0.50f,		-0.50f,		-1.0f,		0.640625f,		0.25f,
        0.50f,		0.0f,		-1.0f,		0.640625f,		0.5f,
        1.0f,		0.0f,		-1.0f,		0.78125f,		0.5f,
        1.0f,		0.0f,		-1.0f,		0.78125f,		0.5f,
        1.0f,		-0.50f,		-1.0f,		0.78125f,		0.25f,
        0.50f,		-0.50f,		-1.0f,		0.640625f,		0.25f,
        -1.00f,		0.00f,		-1.0f,		0.21875f,		0.5f,
        -1.00f,		0.5f,		-1.0f,		0.21875f,		0.75f,
        -0.5f,		0.5f,		-1.0f,		0.359375f,		0.75f,
        -0.5f,		0.5f,		-1.0f,		0.359375f,		0.75f,
        -0.5f,		0.00f,		-1.0f,		0.359375f,		0.5f,
        -1.00f,		0.00f,		-1.0f,		0.21875f,		0.5f,
        -0.50f,		0.00f,		-1.0f,		0.359375f,		0.5f,
        -0.50f,		0.5f,		-1.0f,		0.359375f,		0.75f,
        0.0f,		0.5f,		-1.0f,		0.5f,		    0.75f,
        0.0f,		0.5f,		-1.0f,		0.5f,		    0.75f,
        0.0f,		0.00f,		-1.0f,		0.5f,		    0.5f,
        -0.50f,		0.00f,		-1.0f,		0.359375f,		0.5f,
        0.00f,		0.00f,		-1.0f,		0.5f,		    0.5f,
        0.00f,		0.5f,		-1.0f,		0.5f,		    0.75f,
        0.5f,		0.5f,		-1.0f,		0.640625f,		0.75f,
        0.5f,		0.5f,		-1.0f,		0.640625f,		0.75f,
        0.5f,		0.00f,		-1.0f,		0.640625f,		0.5f,
        0.00f,		0.00f,		-1.0f,		0.5f,		    0.5f,
        0.50f,		0.00f,		-1.0f,		0.640625f,		0.5f,
        0.50f,		0.5f,		-1.0f,		0.640625f,		0.75f,
        1.0f,		0.5f,		-1.0f,		0.78125f,		0.75f,
        1.0f,		0.5f,		-1.0f,		0.78125f,		0.75f,
        1.0f,		0.00f,		-1.0f,		0.78125f,		0.5f,
        0.50f,		0.00f,		-1.0f,		0.640625f,		0.5f,
        -1.00f,		0.50f,		-1.0f,		0.21875f,		0.75f,
        -1.00f,		1.0f,		-1.0f,		0.21875f,		1.0f,
        -0.5f,		1.0f,		-1.0f,		0.359375f,		1.0f,
        -0.5f,		1.0f,		-1.0f,		0.359375f,		1.0f,
        -0.5f,		0.50f,		-1.0f,		0.359375f,		0.75f,
        -1.00f,		0.50f,		-1.0f,		0.21875f,		0.75f,
        -0.50f,		0.50f,		-1.0f,		0.359375f,		0.75f,
        -0.50f,		1.0f,		-1.0f,		0.359375f,		1.0f,
        0.0f,		1.0f,		-1.0f,		0.5f,		    1.0f,
        0.0f,		1.0f,		-1.0f,		0.5f,		    1.0f,
        0.0f,		0.50f,		-1.0f,		0.5f,		    0.75f,
        -0.50f,		0.50f,		-1.0f,		0.359375f,		0.75f,
        0.00f,		0.50f,		-1.0f,		0.5f,		    0.75f,
        0.00f,		1.0f,		-1.0f,		0.5f,		    1.0f,
        0.5f,		1.0f,		-1.0f,		0.640625f,		1.0f,
        0.5f,		1.0f,		-1.0f,		0.640625f,		1.0f,
        0.5f,		0.50f,		-1.0f,		0.640625f,		0.75f,
        0.00f,		0.50f,		-1.0f,		0.5f,		    0.75f,
        0.50f,		0.50f,		-1.0f,		0.640625f,		0.75f,
        0.50f,		1.0f,		-1.0f,		0.640625f,		1.0f,
        1.0f,		1.0f,		-1.0f,		0.78125f,		1.0f,
        1.0f,		1.0f,		-1.0f,		0.78125f,		1.0f,
        1.0f,		0.50f,		-1.0f,		0.78125f,		0.75f,
        0.50f,		0.50f,		-1.0f,		0.640625f,		0.75f,  // front place
            1.0f,	-1.00f,		-1.00f,		0.78125f,		0.0f,
            1.0f,	-0.5f,		-1.00f,		0.78125f,		0.25f,
            1.0f,	-0.5f,		-0.5f,		0.921875f,		0.25f,
            1.0f,	-0.5f,		-0.5f,		0.921875f,		0.25f,
            1.0f,	-1.00f,		-0.5f,		0.921875f,		0.0f,
            1.0f,	-1.00f,		-1.00f,		0.78125f,		0.0f,
            1.0f,	-1.00f,		-0.50f,		0.921875f,		0.0f,
            1.0f,	-0.5f,		-0.50f,		0.921875f,		0.25f,
            1.0f,	-0.5f,		0.0f,		1.0625f,		0.25f,
            1.0f,	-0.5f,		0.0f,		1.0625f,		0.25f,
            1.0f,	-1.00f,		0.0f,		1.0625f,		0.0f,
            1.0f,	-1.00f,		-0.50f,		0.921875f,		0.0f,
            1.0f,	-1.00f,		0.00f,		1.0625f,		0.0f,
            1.0f,	-0.5f,		0.00f,		1.0625f,		0.25f,
            1.0f,	-0.5f,		0.5f,		1.203125f,		0.25f,
            1.0f,	-0.5f,		0.5f,		1.203125f,		0.25f,
            1.0f,	-1.00f,		0.5f,		1.203125f,		0.0f,
            1.0f,	-1.00f,		0.00f,		1.0625f,		0.0f,
            1.0f,	-1.00f,		0.50f,		1.203125f,		0.0f,
            1.0f,	-0.5f,		0.50f,		1.203125f,		0.25f,
            1.0f,	-0.5f,		1.0f,		1.34375f,		0.25f,
            1.0f,	-0.5f,		1.0f,		1.34375f,		0.25f,
            1.0f,	-1.00f,		1.0f,		1.34375f,		0.0f,
            1.0f,	-1.00f,		0.50f,		1.203125f,		0.0f,
            1.0f,	-0.50f,		-1.00f,		0.78125f,		0.25f,
            1.0f,	0.0f,		-1.00f,		0.78125f,		0.5f,
            1.0f,	0.0f,		-0.5f,		0.921875f,		0.5f,
            1.0f,	0.0f,		-0.5f,		0.921875f,		0.5f,
            1.0f,	-0.50f,		-0.5f,		0.921875f,		0.25f,
            1.0f,	-0.50f,		-1.00f,		0.78125f,		0.25f,
            1.0f,	-0.50f,		-0.50f,		0.921875f,		0.25f,
            1.0f,	0.0f,		-0.50f,		0.921875f,		0.5f,
            1.0f,	0.0f,		0.0f,		1.0625f,		0.5f,
            1.0f,	0.0f,		0.0f,		1.0625f,		0.5f,
            1.0f,	-0.50f,		0.0f,		1.0625f,		0.25f,
            1.0f,	-0.50f,		-0.50f,		0.921875f,		0.25f,
            1.0f,	-0.50f,		0.00f,		1.0625f,		0.25f,
            1.0f,	0.0f,		0.00f,		1.0625f,		0.5f,
            1.0f,	0.0f,		0.5f,		1.203125f,		0.5f,
            1.0f,	0.0f,		0.5f,		1.203125f,		0.5f,
            1.0f,	-0.50f,		0.5f,		1.203125f,		0.25f,
            1.0f,	-0.50f,		0.00f,		1.0625f,		0.25f,
            1.0f,	-0.50f,		0.50f,		1.203125f,		0.25f,
            1.0f,	0.0f,		0.50f,		1.203125f,		0.5f,
            1.0f,	0.0f,		1.0f,		1.34375f,		0.5f,
            1.0f,	0.0f,		1.0f,		1.34375f,		0.5f,
            1.0f,	-0.50f,		1.0f,		1.34375f,		0.25f,
            1.0f,	-0.50f,		0.50f,		1.203125f,		0.25f,
            1.0f,	0.00f,		-1.00f,		0.78125f,		0.5f,
            1.0f,	0.5f,		-1.00f,		0.78125f,		0.75f,
            1.0f,	0.5f,		-0.5f,		0.921875f,		0.75f,
            1.0f,	0.5f,		-0.5f,		0.921875f,		0.75f,
            1.0f,	0.00f,		-0.5f,		0.921875f,		0.5f,
            1.0f,	0.00f,		-1.00f,		0.78125f,		0.5f,
            1.0f,	0.00f,		-0.50f,		0.921875f,		0.5f,
            1.0f,	0.5f,		-0.50f,		0.921875f,		0.75f,
            1.0f,	0.5f,		0.0f,		1.0625f,		0.75f,
            1.0f,	0.5f,		0.0f,		1.0625f,		0.75f,
            1.0f,	0.00f,		0.0f,		1.0625f,		0.5f,
            1.0f,	0.00f,		-0.50f,		0.921875f,		0.5f,
            1.0f,	0.00f,		0.00f,		1.0625f,		0.5f,
            1.0f,	0.5f,		0.00f,		1.0625f,		0.75f,
            1.0f,	0.5f,		0.5f,		1.203125f,		0.75f,
            1.0f,	0.5f,		0.5f,		1.203125f,		0.75f,
            1.0f,	0.00f,		0.5f,		1.203125f,		0.5f,
            1.0f,	0.00f,		0.00f,		1.0625f,		0.5f,
            1.0f,	0.00f,		0.50f,		1.203125f,		0.5f,
            1.0f,	0.5f,		0.50f,		1.203125f,		0.75f,
            1.0f,	0.5f,		1.0f,		1.34375f,		0.75f,
            1.0f,	0.5f,		1.0f,		1.34375f,		0.75f,
            1.0f,	0.00f,		1.0f,		1.34375f,		0.5f,
            1.0f,	0.00f,		0.50f,		1.203125f,		0.5f,
            1.0f,	0.50f,		-1.00f,		0.78125f,		0.75f,
            1.0f,	1.0f,		-1.00f,		0.78125f,		1.0f,
            1.0f,	1.0f,		-0.5f,		0.921875f,		1.0f,
            1.0f,	1.0f,		-0.5f,		0.921875f,		1.0f,
            1.0f,	0.50f,		-0.5f,		0.921875f,		0.75f,
            1.0f,	0.50f,		-1.00f,		0.78125f,		0.75f,
            1.0f,	0.50f,		-0.50f,		0.921875f,		0.75f,
            1.0f,	1.0f,		-0.50f,		0.921875f,		1.0f,
            1.0f,	1.0f,		0.0f,		1.0625f,		1.0f,
            1.0f,	1.0f,		0.0f,		1.0625f,		1.0f,
            1.0f,	0.50f,		0.0f,		1.0625f,		0.75f,
            1.0f,	0.50f,		-0.50f,		0.921875f,		0.75f,
            1.0f,	0.50f,		0.00f,		1.0625f,		0.75f,
            1.0f,	1.0f,		0.00f,		1.0625f,		1.0f,
            1.0f,	1.0f,		0.5f,		1.203125f,		1.0f,
            1.0f,	1.0f,		0.5f,		1.203125f,		1.0f,
            1.0f,	0.50f,		0.5f,		1.203125f,		0.75f,
            1.0f,	0.50f,		0.00f,		1.0625f,		0.75f,
            1.0f,	0.50f,		0.50f,		1.203125f,		0.75f,
            1.0f,	1.0f,		0.50f,		1.203125f,		1.0f,
            1.0f,	1.0f,		1.0f,		1.34375f,		1.0f,
            1.0f,	1.0f,		1.0f,		1.34375f,		1.0f,
            1.0f,	0.50f,		1.0f,		1.34375f,		0.75f,
            1.0f,	0.50f,		0.50f,		1.203125f,		0.75f,  // right plane
            -1.0f, -1.00f, 1.00f, -0.34375f, 0.0f,
            -1.0f, -0.5f, 1.00f, -0.34375f, 0.25f,
            -1.0f, -0.5f, 0.5f, -0.203125f, 0.25f,
            -1.0f, -0.5f, 0.5f, -0.203125f, 0.25f,
            -1.0f, -1.00f, 0.5f, -0.203125f, 0.0f,
            -1.0f, -1.00f, 1.00f, -0.34375f, 0.0f,
            -1.0f, -1.00f, 0.50f, -0.203125f, 0.0f,
            -1.0f, -0.5f, 0.50f, -0.203125f, 0.25f,
            -1.0f, -0.5f, 0.0f, -0.0625f, 0.25f,
            -1.0f, -0.5f, 0.0f, -0.0625f, 0.25f,
            -1.0f, -1.00f, 0.0f, -0.0625f, 0.0f,
            -1.0f, -1.00f, 0.50f, -0.203125f, 0.0f,
            -1.0f, -1.00f, 0.00f, -0.0625f, 0.0f,
            -1.0f, -0.5f, 0.00f, -0.0625f, 0.25f,
            -1.0f, -0.5f, -0.5f, 0.078125f, 0.25f,
            -1.0f, -0.5f, -0.5f, 0.078125f, 0.25f,
            -1.0f, -1.00f, -0.5f, 0.078125f, 0.0f,
            -1.0f, -1.00f, 0.00f, -0.0625f, 0.0f,
            -1.0f, -1.00f, -0.50f, 0.078125f, 0.0f,
            -1.0f, -0.5f, -0.50f, 0.078125f, 0.25f,
            -1.0f, -0.5f, -1.0f, 0.21875f, 0.25f,
            -1.0f, -0.5f, -1.0f, 0.21875f, 0.25f,
            -1.0f, -1.00f, -1.0f, 0.21875f, 0.0f,
            -1.0f, -1.00f, -0.50f, 0.078125f, 0.0f,
            -1.0f, -0.50f, 1.00f, -0.34375f, 0.25f,
            -1.0f, 0.0f, 1.00f, -0.34375f, 0.5f,
            -1.0f, 0.0f, 0.5f, -0.203125f, 0.5f,
            -1.0f, 0.0f, 0.5f, -0.203125f, 0.5f,
            -1.0f, -0.50f, 0.5f, -0.203125f, 0.25f,
            -1.0f, -0.50f, 1.00f, -0.34375f, 0.25f,
            -1.0f, -0.50f, 0.50f, -0.203125f, 0.25f,
            -1.0f, 0.0f, 0.50f, -0.203125f, 0.5f,
            -1.0f, 0.0f, 0.0f, -0.0625f, 0.5f,
            -1.0f, 0.0f, 0.0f, -0.0625f, 0.5f,
            -1.0f, -0.50f, 0.0f, -0.0625f, 0.25f,
            -1.0f, -0.50f, 0.50f, -0.203125f, 0.25f,
            -1.0f, -0.50f, 0.00f, -0.0625f, 0.25f,
            -1.0f, 0.0f, 0.00f, -0.0625f, 0.5f,
            -1.0f, 0.0f, -0.5f, 0.078125f, 0.5f,
            -1.0f, 0.0f, -0.5f, 0.078125f, 0.5f,
            -1.0f, -0.50f, -0.5f, 0.078125f, 0.25f,
            -1.0f, -0.50f, 0.00f, -0.0625f, 0.25f,
            -1.0f, -0.50f, -0.50f, 0.078125f, 0.25f,
            -1.0f, 0.0f, -0.50f, 0.078125f, 0.5f,
            -1.0f, 0.0f, -1.0f, 0.21875f, 0.5f,
            -1.0f, 0.0f, -1.0f, 0.21875f, 0.5f,
            -1.0f, -0.50f, -1.0f, 0.21875f, 0.25f,
            -1.0f, -0.50f, -0.50f, 0.078125f, 0.25f,
            -1.0f, 0.00f, 1.00f, -0.34375f, 0.5f,
            -1.0f, 0.5f, 1.00f, -0.34375f, 0.75f,
            -1.0f, 0.5f, 0.5f, -0.203125f, 0.75f,
            -1.0f, 0.5f, 0.5f, -0.203125f, 0.75f,
            -1.0f, 0.00f, 0.5f, -0.203125f, 0.5f,
            -1.0f, 0.00f, 1.00f, -0.34375f, 0.5f,
            -1.0f, 0.00f, 0.50f, -0.203125f, 0.5f,
            -1.0f, 0.5f, 0.50f, -0.203125f, 0.75f,
            -1.0f, 0.5f, 0.0f, -0.0625f, 0.75f,
            -1.0f, 0.5f, 0.0f, -0.0625f, 0.75f,
            -1.0f, 0.00f, 0.0f, -0.0625f, 0.5f,
            -1.0f, 0.00f, 0.50f, -0.203125f, 0.5f,
            -1.0f, 0.00f, 0.00f, -0.0625f, 0.5f,
            -1.0f, 0.5f, 0.00f, -0.0625f, 0.75f,
            -1.0f, 0.5f, -0.5f, 0.078125f, 0.75f,
            -1.0f, 0.5f, -0.5f, 0.078125f, 0.75f,
            -1.0f, 0.00f, -0.5f, 0.078125f, 0.5f,
            -1.0f, 0.00f, 0.00f, -0.0625f, 0.5f,
            -1.0f, 0.00f, -0.50f, 0.078125f, 0.5f,
            -1.0f, 0.5f, -0.50f, 0.078125f, 0.75f,
            -1.0f, 0.5f, -1.0f, 0.21875f, 0.75f,
            -1.0f, 0.5f, -1.0f, 0.21875f, 0.75f,
            -1.0f, 0.00f, -1.0f, 0.21875f, 0.5f,
            -1.0f, 0.00f, -0.50f, 0.078125f, 0.5f,
            -1.0f, 0.50f, 1.00f, -0.34375f, 0.75f,
            -1.0f, 1.0f, 1.00f, -0.34375f, 1.0f,
            -1.0f, 1.0f, 0.5f, -0.203125f, 1.0f,
            -1.0f, 1.0f, 0.5f, -0.203125f, 1.0f,
            -1.0f, 0.50f, 0.5f, -0.203125f, 0.75f,
            -1.0f, 0.50f, 1.00f, -0.34375f, 0.75f,
            -1.0f, 0.50f, 0.50f, -0.203125f, 0.75f,
            -1.0f, 1.0f, 0.50f, -0.203125f, 1.0f,
            -1.0f, 1.0f, 0.0f, -0.0625f, 1.0f,
            -1.0f, 1.0f, 0.0f, -0.0625f, 1.0f,
            -1.0f, 0.50f, 0.0f, -0.0625f, 0.75f,
            -1.0f, 0.50f, 0.50f, -0.203125f, 0.75f,
            -1.0f, 0.50f, 0.00f, -0.0625f, 0.75f,
            -1.0f, 1.0f, 0.00f, -0.0625f, 1.0f,
            -1.0f, 1.0f, -0.5f, 0.078125f, 1.0f,
            -1.0f, 1.0f, -0.5f, 0.078125f, 1.0f,
            -1.0f, 0.50f, -0.5f, 0.078125f, 0.75f,
            -1.0f, 0.50f, 0.00f, -0.0625f, 0.75f,
            -1.0f, 0.50f, -0.50f, 0.078125f, 0.75f,
            -1.0f, 1.0f, -0.50f, 0.078125f, 1.0f,
            -1.0f, 1.0f, -1.0f, 0.21875f, 1.0f,
            -1.0f, 1.0f, -1.0f, 0.21875f, 1.0f,
            -1.0f, 0.50f, -1.0f, 0.21875f, 0.75f,
            -1.0f, 0.50f, -0.50f, 0.078125f, 0.75f, //left plane
                -1.00f, 1.0f, -1.00f, 0.21875f, 1.0f,
                -1.00f, 1.0f, -0.5f, 0.21875f, 1.25f,
                -0.5f, 1.0f, -0.5f, 0.359375f, 1.25f,
                -0.5f, 1.0f, -0.5f, 0.359375f, 1.25f,
                -0.5f, 1.0f, -1.00f, 0.359375f, 1.0f,
                -1.00f, 1.0f, -1.00f, 0.21875f, 1.0f,
                -0.50f, 1.0f, -1.00f, 0.359375f, 1.0f,
                -0.50f, 1.0f, -0.5f, 0.359375f, 1.25f,
                0.0f, 1.0f, -0.5f, 0.5f, 1.25f,
                0.0f, 1.0f, -0.5f, 0.5f, 1.25f,
                0.0f, 1.0f, -1.00f, 0.5f, 1.0f,
                -0.50f, 1.0f, -1.00f, 0.359375f, 1.0f,
                0.00f, 1.0f, -1.00f, 0.5f, 1.0f,
                0.00f, 1.0f, -0.5f, 0.5f, 1.25f,
                0.5f, 1.0f, -0.5f, 0.640625f, 1.25f,
                0.5f, 1.0f, -0.5f, 0.640625f, 1.25f,
                0.5f, 1.0f, -1.00f, 0.640625f, 1.0f,
                0.00f, 1.0f, -1.00f, 0.5f, 1.0f,
                0.50f, 1.0f, -1.00f, 0.640625f, 1.0f,
                0.50f, 1.0f, -0.5f, 0.640625f, 1.25f,
                1.0f, 1.0f, -0.5f, 0.78125f, 1.25f,
                1.0f, 1.0f, -0.5f, 0.78125f, 1.25f,
                1.0f, 1.0f, -1.00f, 0.78125f, 1.0f,
                0.50f, 1.0f, -1.00f, 0.640625f, 1.0f,
                -1.00f, 1.0f, -0.50f, 0.21875f, 1.25f,
                -1.00f, 1.0f, 0.0f, 0.21875f, 1.5f,
                -0.5f, 1.0f, 0.0f, 0.359375f, 1.5f,
                -0.5f, 1.0f, 0.0f, 0.359375f, 1.5f,
                -0.5f, 1.0f, -0.50f, 0.359375f, 1.25f,
                -1.00f, 1.0f, -0.50f, 0.21875f, 1.25f,
                -0.50f, 1.0f, -0.50f, 0.359375f, 1.25f,
                -0.50f, 1.0f, 0.0f, 0.359375f, 1.5f,
                0.0f, 1.0f, 0.0f, 0.5f, 1.5f,
                0.0f, 1.0f, 0.0f, 0.5f, 1.5f,
                0.0f, 1.0f, -0.50f, 0.5f, 1.25f,
                -0.50f, 1.0f, -0.50f, 0.359375f, 1.25f,
                0.00f, 1.0f, -0.50f, 0.5f, 1.25f,
                0.00f, 1.0f, 0.0f, 0.5f, 1.5f,
                0.5f, 1.0f, 0.0f, 0.640625f, 1.5f,
                0.5f, 1.0f, 0.0f, 0.640625f, 1.5f,
                0.5f, 1.0f, -0.50f, 0.640625f, 1.25f,
                0.00f, 1.0f, -0.50f, 0.5f, 1.25f,
                0.50f, 1.0f, -0.50f, 0.640625f, 1.25f,
                0.50f, 1.0f, 0.0f, 0.640625f, 1.5f,
                1.0f, 1.0f, 0.0f, 0.78125f, 1.5f,
                1.0f, 1.0f, 0.0f, 0.78125f, 1.5f,
                1.0f, 1.0f, -0.50f, 0.78125f, 1.25f,
                0.50f, 1.0f, -0.50f, 0.640625f, 1.25f,
                -1.00f, 1.0f, 0.00f, 0.21875f, 1.5f,
                -1.00f, 1.0f, 0.5f, 0.21875f, 1.75f,
                -0.5f, 1.0f, 0.5f, 0.359375f, 1.75f,
                -0.5f, 1.0f, 0.5f, 0.359375f, 1.75f,
                -0.5f, 1.0f, 0.00f, 0.359375f, 1.5f,
                -1.00f, 1.0f, 0.00f, 0.21875f, 1.5f,
                -0.50f, 1.0f, 0.00f, 0.359375f, 1.5f,
                -0.50f, 1.0f, 0.5f, 0.359375f, 1.75f,
                0.0f, 1.0f, 0.5f, 0.5f, 1.75f,
                0.0f, 1.0f, 0.5f, 0.5f, 1.75f,
                0.0f, 1.0f, 0.00f, 0.5f, 1.5f,
                -0.50f, 1.0f, 0.00f, 0.359375f, 1.5f,
                0.00f, 1.0f, 0.00f, 0.5f, 1.5f,
                0.00f, 1.0f, 0.5f, 0.5f, 1.75f,
                0.5f, 1.0f, 0.5f, 0.640625f, 1.75f,
                0.5f, 1.0f, 0.5f, 0.640625f, 1.75f,
                0.5f, 1.0f, 0.00f, 0.640625f, 1.5f,
                0.00f, 1.0f, 0.00f, 0.5f, 1.5f,
                0.50f, 1.0f, 0.00f, 0.640625f, 1.5f,
                0.50f, 1.0f, 0.5f, 0.640625f, 1.75f,
                1.0f, 1.0f, 0.5f, 0.78125f, 1.75f,
                1.0f, 1.0f, 0.5f, 0.78125f, 1.75f,
                1.0f, 1.0f, 0.00f, 0.78125f, 1.5f,
                0.50f, 1.0f, 0.00f, 0.640625f, 1.5f,
                -1.00f, 1.0f, 0.50f, 0.21875f, 1.75f,
                -1.00f, 1.0f, 1.0f, 0.21875f, 2.0f,
                -0.5f, 1.0f, 1.0f, 0.359375f, 2.0f,
                -0.5f, 1.0f, 1.0f, 0.359375f, 2.0f,
                -0.5f, 1.0f, 0.50f, 0.359375f, 1.75f,
                -1.00f, 1.0f, 0.50f, 0.21875f, 1.75f,
                -0.50f, 1.0f, 0.50f, 0.359375f, 1.75f,
                -0.50f, 1.0f, 1.0f, 0.359375f, 2.0f,
                0.0f, 1.0f, 1.0f, 0.5f, 2.0f,
                0.0f, 1.0f, 1.0f, 0.5f, 2.0f,
                0.0f, 1.0f, 0.50f, 0.5f, 1.75f,
                -0.50f, 1.0f, 0.50f, 0.359375f, 1.75f,
                0.00f, 1.0f, 0.50f, 0.5f, 1.75f,
                0.00f, 1.0f, 1.0f, 0.5f, 2.0f,
                0.5f, 1.0f, 1.0f, 0.640625f, 2.0f,
                0.5f, 1.0f, 1.0f, 0.640625f, 2.0f,
                0.5f, 1.0f, 0.50f, 0.640625f, 1.75f,
                0.00f, 1.0f, 0.50f, 0.5f, 1.75f,
                0.50f, 1.0f, 0.50f, 0.640625f, 1.75f,
                0.50f, 1.0f, 1.0f, 0.640625f, 2.0f,
                1.0f, 1.0f, 1.0f, 0.78125f, 2.0f,
                1.0f, 1.0f, 1.0f, 0.78125f, 2.0f,
                1.0f, 1.0f, 0.50f, 0.78125f, 1.75f,
                0.50f, 1.0f, 0.50f, 0.640625f, 1.75f
                //top plane

    };

    unsigned int planeVAO, planeVBO;
    glGenVertexArrays(1, &planeVAO);
    glBindVertexArray(planeVAO);

    glGenBuffers(1, &planeVBO);
    glBindBuffer(GL_ARRAY_BUFFER, planeVBO);

    glBufferData(GL_ARRAY_BUFFER, sizeof(planeVertices), planeVertices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // load textures
    // -------------
    cv::Mat img_l, img_r;
    img_r = vs_r.getframe();
    img_l = vs_l.getframe();



    plane.use();
    unsigned int planeTexture_r = loadTexture(img_r);
    plane.setInt("texture1", 0);
    unsigned int planeTexture_l = loadTexture(img_l);
    plane.setInt("texture2", 1);

    glm::mat4 tran_r = glm::mat4(1.0f);
    tran_r = glm::rotate(tran_r, glm::radians(-0.99059548f), glm::vec3(0.0f, 0.0f, 1.0f));
    tran_r = glm::rotate(tran_r, glm::radians(-10.54798735f), glm::vec3(0.0f, 1.0f, 0.0f));
    tran_r = glm::rotate(tran_r, glm::radians(1.74824728f), glm::vec3(1.0f, 0.0f, 0.0f));
    plane.setMat4("tran_r", tran_r);


    glm::mat4 tran_l = glm::mat4(1.0f);
    tran_l = glm::rotate(tran_l, glm::radians(0.47431445f), glm::vec3(0.0f, 0.0f, 1.0f));
    tran_l = glm::rotate(tran_l, glm::radians(18.57714284f), glm::vec3(0.0f, 1.0f, 0.0f));
    tran_l = glm::rotate(tran_l, glm::radians(4.00919561f), glm::vec3(1.0f, 0.0f, 0.0f));
    tran_l = glm::translate(tran_l, glm::vec3(-0.215f, 0.0f, 0.0f));
    //tran_l = glm::translate(tran_l, glm::vec3(-0.41f, 0.0f, 0.0f));
    plane.setMat4("tran_l", tran_l);


    while (!glfwWindowShouldClose(window)) {

        processInput(window);

        glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        plane.use();
        glm::mat4 model = glm::mat4(1.0f);
        glm::mat4 view = camera.GetViewMatrix();
        glm::mat4 projection = glm::perspective(glm::radians(camera.Zoom), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);

        plane.setMat4("model", model);
        plane.setMat4("view", view);
        plane.setMat4("projection", projection);


        glBindVertexArray(planeVAO);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, planeTexture_r);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, planeTexture_l);
        glDrawArrays(GL_TRIANGLES, 0, 384);

        updateTexture(vs_r.getframe(), planeTexture_r);
        updateTexture(vs_l.getframe(), planeTexture_l);


        glBindVertexArray(0);
        glfwSwapBuffers(window);
        glfwPollEvents();

    }

    vs_r.finish(); vs_l.finish();
    while (vs_r.checkOpened() || vs_l.checkOpened()) {
    }

    glDeleteVertexArrays(1, &planeVAO);
    glDeleteBuffers(1, &planeVBO);
    glDeleteProgram(plane.ID);



    glfwTerminate();
    return 0;

}


void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}


void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
}

void mouse_callback(GLFWwindow* window, double xposIn, double yposIn)
{
    float xpos = static_cast<float>(xposIn);
    float ypos = static_cast<float>(yposIn);
    if (firstMouse)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top

    lastX = xpos;
    lastY = ypos;

    camera.ProcessMouseMovement(xoffset, yoffset);
}

void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    camera.ProcessMouseScroll(static_cast<float>(yoffset));
}


unsigned int loadTexture(cv::Mat img)
{
    unsigned int textureID;
    glGenTextures(1, &textureID);

    if (img.empty()) {
        std::cout << "Texture failed to load " << std::endl;
    }
    else {
        glBindTexture(GL_TEXTURE_2D, textureID);

        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, img.cols, img.rows, 0, GL_RGB, GL_UNSIGNED_BYTE, img.data);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);



    }

    return textureID;
}

unsigned int loadTexture(char const* path)
{
    unsigned int textureID;
    glGenTextures(1, &textureID);

    cv::Mat image = cv::imread(path);
    if (image.empty()) {
        std::cout << "Texture failed to load at path: " << path << std::endl;
    }
    else {
        cv::flip(image, image, 0);

        glBindTexture(GL_TEXTURE_2D, textureID);

        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, image.cols, image.rows, 0, GL_BGR, GL_UNSIGNED_BYTE, image.data);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

        //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);

        float borderColor[] = { 1.0f, 1.0f, 0.0f, 1.0f };
        glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, borderColor);
        

    }

    return textureID;
}


unsigned int loadTexture(cv::VideoCapture cap) {
    cv::Mat frame;
    bool ret = cap.read(frame);

    unsigned int textureID;
    glGenTextures(1, &textureID);

    if (!ret) {
        std::cout << "Can't receive frame (stream end?). Exiting ...\n";
    }
    else {
        cv::flip(frame, frame, 0);

        glBindTexture(GL_TEXTURE_2D, textureID);

        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, frame.cols, frame.rows, 0, GL_BGR, GL_UNSIGNED_BYTE, frame.data);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    }
    return textureID;

}

void updateTexture(cv::VideoCapture cap, unsigned int textureID) {
    cv::Mat frame;
    bool ret;

    ret = cap.grab();


    if (!ret) {
        std::cout << "Can't receive frame (stream end?). Exiting ...\n";
    }
    else {
        cap.retrieve(frame);
        cv::flip(frame, frame, 0);
        cv::cvtColor(frame, frame, cv::COLOR_BGR2RGB);

        glBindTexture(GL_TEXTURE_2D, textureID);
        glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, frame.cols, frame.rows, GL_RGB, GL_UNSIGNED_BYTE, frame.data);

    }
}

void updateTexture(cv::Mat frame, unsigned int textureID) {

    if (frame.empty()) {
        std::cout << "Can't receive frame (stream end?). Exiting ...\n";
    }
    else {

        glBindTexture(GL_TEXTURE_2D, textureID);
        glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, frame.cols, frame.rows, GL_RGB, GL_UNSIGNED_BYTE, frame.data);

    }
}