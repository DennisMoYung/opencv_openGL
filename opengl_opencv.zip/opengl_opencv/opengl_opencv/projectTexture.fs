#version 330 core
in vec2 TexCoords;

out vec4 FragColor;

uniform sampler2D texture1; //right
uniform sampler2D texture2;

uniform mat4 tran_r;
uniform mat4 tran_l;

void main(){

	//FragColor = texture(texture1, TexCoords);
	//mat4 tranInv = mat4(1.0f);
	//tranInv = rotate(tranInv, radians(45.0f), vec3(0.0f, 1.0f, 0.0f));

	//tranInv = inverse(tranInv);
	vec4 result_r = (tran_r * vec4(TexCoords, 1.0f, 1.0f));
	vec2 normalizeResult_r = vec2(result_r.x / result_r.z, result_r.y / result_r.z);

	vec4 result_l = (tran_l * vec4(TexCoords, 1.0f, 1.0f));
	vec2 normalizeResult_l = vec2(result_l.x / result_l.z, result_l.y / result_l.z);; 
	
	if(normalizeResult_r.x >= 0 && normalizeResult_r.x <= 1 && normalizeResult_r.y <= 1 && normalizeResult_r.y <= 1 && normalizeResult_l.x >= 0 && normalizeResult_l.x <= 1 && normalizeResult_l.y <= 1 && normalizeResult_l.y <= 1){
		FragColor = texture(texture1, normalizeResult_r);

		//vec3 color1 = texture(texture1, normalizeResult_r).rgb;
		//vec3 color2 = texture(texture2, normalizeResult_l).rgb;
		//float a = smoothstep(0.21875, 0.78125, TexCoords.x);
		//FragColor = vec4(mix(color2, color1, a) ,1.0f);

	}else if(normalizeResult_r.x >= 0 && normalizeResult_r.x <= 1 && normalizeResult_r.y <= 1 && normalizeResult_r.y <= 1){
		FragColor = texture(texture1, normalizeResult_r);
	} else{
		FragColor = texture(texture2, normalizeResult_l);
	}
	

	

}
